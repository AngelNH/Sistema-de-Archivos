#include <users.h>

int getuid()
{
	return(1);
}

int getgid()
{
	return(1);
}
