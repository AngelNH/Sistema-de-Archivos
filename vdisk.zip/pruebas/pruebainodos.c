#include <stdio.h>
#include "../include/inode.h"

int main()
{
	setninode(0, "Holamundo",0644, 100, 100);
}