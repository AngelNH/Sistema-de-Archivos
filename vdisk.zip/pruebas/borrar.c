#include "../include/filesapi.h"

int main()
{
	char fname[20]="oracion.txt";
	vdunlink(fname);
}