int writeblock(int block,char *buffer);
int readblock(int block,char *buffer);
