int vdreadseclog(int logunit, int seclog, char *buffer);
int vdwriteseclog(int logunit, int seclog, char *buffer);