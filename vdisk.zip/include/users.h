int getuid();
int getgid();